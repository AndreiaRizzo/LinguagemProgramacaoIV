<?php
    require_once("cabecalho.php");
?>

    <h1>Sistema PHP + MySql</h1>

<?php
    require_once("rodape.html");